const FeedbackData = [
    {
        id: 1,
        rating: 10,
        text: 'This is feedback item 1 coming from the backend',
    },
    {
        id: 2,
        rating: 9,
        text: 'This is feedback item 2 coming from the backend',
    },
    {
        text: 'This is feedback item 3 coming from the backend',
        rating: 8,
        id: 3,
    },
];

export default FeedbackData;