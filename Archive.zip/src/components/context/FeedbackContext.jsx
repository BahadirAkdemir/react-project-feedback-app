import {useState, createContext} from "react";
import {v4 as uuidv4} from 'uuid'

const FeedbackContext = createContext()

export const FeedbackProvider = ({children}) => {
    const [feedback, setFeedback] = useState([{
        id: 1,
        text: 'bu bir numaralı olan',
        rating: 10
    },
        {
            id: 2,
            text: 'bu iki numaralı olan',
            rating: 9
        },
        {
            id: 3,
            text: 'bu uc numaralı olan',
            rating: 8
        }])
    const addFeedback = (tempFeedback) => {
        tempFeedback.id = uuidv4()
        setFeedback([tempFeedback,...feedback])
    }

    const deleteFeedback = (idx) => {
        if (window.confirm("Are you sure?")) {
            setFeedback(feedback.filter((item) => item.id !== idx));
        }
    }

    const [feedbackEdit, setFeedbackEdit] = useState(
        {
            item: {},
            edit: false
        }
    )

    const editFeedback = (item) =>
    {
        setFeedbackEdit(
            {
                item,
                edit: true
            }
        )
    }

    const updateFeedback = (id, updItem) => {
        const updatedData = feedback.map(item => {
            if (item.id === id) {
                return { ...item, ...updItem };
            }
            return item;
        });

        setFeedback(updatedData);
        console.log(feedback)
    };

     return <FeedbackContext.Provider value={{feedback, addFeedback, deleteFeedback, editFeedback, feedbackEdit, updateFeedback}}>
        {children}
    </FeedbackContext.Provider>
}

export default FeedbackContext